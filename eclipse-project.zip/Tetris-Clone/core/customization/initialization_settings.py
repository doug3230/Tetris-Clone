'''
Created on Oct 13, 2014

@author: Richard
'''
INIT_SCREEN_SIZE = (400, 600)
INIT_SCREEN_POSITION = None
INIT_CENTERED = True
from constants.colours import GRAY
INIT_BACKGROUND = GRAY

'''
Created on Oct 13, 2014

@author: Richard
'''
DISPLAY_CAPTION = "Tetris Clone"
DISPLAY_ICON = "no_icon.gif"
DISPLAY_DOUBLE_BUFFERED = True
DISPLAY_RESIZABLE = False
DISPLAY_FPS = 30

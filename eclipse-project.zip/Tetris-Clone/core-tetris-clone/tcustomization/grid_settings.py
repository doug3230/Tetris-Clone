'''
Created on Feb 28, 2016

@author: Richard
'''
GRID_CAMERA_W = 12
GRID_CAMERA_H = 20
from pygame import Rect
GRID_CAMERA_RECT = Rect((0, 0), (300, 600))
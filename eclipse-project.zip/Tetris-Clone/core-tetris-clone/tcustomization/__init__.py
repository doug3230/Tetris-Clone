from grid_settings import *
from score_board_settings import *
from tetromino_settings import *
from game_settings import *
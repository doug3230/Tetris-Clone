'''
Created on Mar 10, 2016

@author: Richard
'''
GAME_FALL_SECONDS = 0.25